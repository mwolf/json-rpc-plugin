<?php

$lang['view'] = 'View page as slide show';
