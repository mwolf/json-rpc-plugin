<?php

$lang['allowed'] = 'allowed users (format: user1; user2 )';
$lang['allow_all'] = 'allow everyone';


