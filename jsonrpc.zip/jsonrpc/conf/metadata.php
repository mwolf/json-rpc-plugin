<?php

$meta['allow_all'] = array('onoff');
$meta['allowed'] = array('string');


