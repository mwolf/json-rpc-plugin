<?php

$conf['allow_all'] = '';
$conf['allowed']    = '';


